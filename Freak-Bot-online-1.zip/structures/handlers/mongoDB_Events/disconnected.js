module.exports = {
  name: "disconnected",

  async execute(client) {
    client.logger(`MongoDB have been disconnected at ${new Date()}`.brightRed)
  }
}

/**
 * @INFO
 * Bot Coded by Zedro#2742 | https://discord.gg/milanio
 * @INFO
 * Work for Milanio Development | https://discord.gg/milanio
 * @INFO
 * Please Mention Us Milanio Development, When Using This Code!
 * @INFO
 */